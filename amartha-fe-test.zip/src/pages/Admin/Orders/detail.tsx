export const OrderDetail = () => {
    return (
        <div>
            <h1>Order Detail</h1>
        </div>
    );
}