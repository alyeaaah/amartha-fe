export const imgExclusiveTreasures = 'https://res.cloudinary.com/doqyrkqgw/image/upload/v1750365636/Brown_Simple_Photo_Typography_Daily_Motivation_Instagram_Story_ze9q3q.webp';
